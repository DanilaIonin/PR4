﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVisits.xaml
    /// </summary>
    public partial class PageVisits : Page
    {
        public PageVisits()
        {
            InitializeComponent();
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
        }

        private void MenuAddVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits(null));
        }

        private void MenuEditVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits((Visits)DtgSQLV.SelectedItem));
        }

        private void MenuDelVisit_Click(object sender, RoutedEventArgs e)
        {
            var visitsForRemoving = DtgSQLV.SelectedItems.Cast<Visits>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {visitsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities2.GetContext().Visits.RemoveRange(visitsForRemoving);
                    PolyclinicEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionDoctors_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDoctorsListView());
        }

        private void BtnTransitionPatients_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePatientsListView());
        }

        private void MenuSortDiagnosis1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.OrderBy(x => x.DiagnosisP).ToList();
        }

        private void MenuSortDiagnosis2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.OrderByDescending(x => x.DiagnosisP).ToList();
        }
        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
        }

        private void MenuFilterVisit1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.Where(x => x.CurrentStatusP == "Больной").ToList();
        }

        private void MenuFilterVisit2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.Where(x => x.CurrentStatusP == "Здоров").ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
        }

        private void txbSearchP_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.Where(x => x.Patients.SurnameP.ToLower().Contains(txbSearchP.Text.ToLower())).ToList();
            }
            if (txbSearchP.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
        }

        private void txbSearchD_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.Where(x => x.Doctors.SurnameD.ToLower().Contains(txbSearchD.Text.ToLower())).ToList();
            }
            if (txbSearchD.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities2.GetContext().Visits.ToList();
        }

        private void MenuExportToExcelVisits_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Фамилия пациента";
            worksheet.Cells[3][IndexRows] = "Дата визита";
            worksheet.Cells[4][IndexRows] = "Время визита";
            worksheet.Cells[5][IndexRows] = "Статус";
            worksheet.Cells[6][IndexRows] = "Диагноз";
            worksheet.Cells[7][IndexRows] = "Фамилия доктора";
            worksheet.Cells[8][IndexRows] = "Дата начала лечения";
            Excel.Range headerRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[8][1]];
            headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            headerRange.Font.Bold = true;
            headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            headerRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<Visits> printItems = new List<Visits>();
            for (int i = 0; i < DtgSQLV.Items.Count; i++) printItems.Add((Visits)DtgSQLV.Items[i]);
            //var printItems = MiningFossilsEntities.GetContext().FossilsBD.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.Patients.SurnameP;
                worksheet.Cells[3][IndexRows + 1] = item.DateOfVisit;
                worksheet.Cells[4][IndexRows + 1] = item.TimeOfVisit.ToString();
                worksheet.Cells[5][IndexRows + 1] = item.CurrentStatusP;
                worksheet.Cells[6][IndexRows + 1] = item.DiagnosisP;
                worksheet.Cells[7][IndexRows + 1] = item.Doctors.SurnameD;
                worksheet.Cells[8][IndexRows + 1] = item.StartDateOfTreatnent;
                IndexRows++;

                Excel.Range bodyRange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[8][IndexRows]];
                bodyRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[IndexRows, 1]];
                numbersRange.Font.Italic = true;
            }
            worksheet.Name = "Визиты";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }
    }
}
