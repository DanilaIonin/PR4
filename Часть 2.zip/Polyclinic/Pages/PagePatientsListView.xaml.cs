﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;
using Excel = Microsoft.Office.Interop.Excel;
namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePatientsListView.xaml
    /// </summary>
    public partial class PagePatientsListView : Page
    {
        public PagePatientsListView()
        {
            InitializeComponent();
            var currentPatients = PolyclinicEntities2.GetContext().Patients.ToList();
            LTVP.ItemsSource = currentPatients;
        }

    private void MenuAddPatient_Click(object sender, RoutedEventArgs e)
    {
        Classes.ClassFrame.frmObj.Navigate(new PageAddPatients(null));
    }

    private void MenuEditPatient_Click(object sender, RoutedEventArgs e)
    {
        Classes.ClassFrame.frmObj.Navigate(new PageAddPatients((Patients)LTVP.SelectedItem));
    }

    private void MenuDelPatient_Click(object sender, RoutedEventArgs e)
    {
        var patientsForRemoving = LTVP.SelectedItems.Cast<Patients>().ToList();
        if (MessageBox.Show($"Вы точно хотите удалить следующие {patientsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            try
            {
                 PolyclinicEntities2.GetContext().Patients.RemoveRange(patientsForRemoving);
                PolyclinicEntities2.GetContext().SaveChanges();
                MessageBox.Show("Данные удалены!");
                LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

    private void BtnTransitionVisit_Click(object sender, RoutedEventArgs e)
    {
        Classes.ClassFrame.frmObj.Navigate(new PageVisits());
    }

    private void BtnTransitionDoctor_Click(object sender, RoutedEventArgs e)
    {
        Classes.ClassFrame.frmObj.Navigate(new PageDoctorsListView());
    }

    private void txbSearchPatSur_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (LTVP.ItemsSource != null)
        {
            LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.Where(x => x.SurnameP.ToLower().Contains(txbSearchPatSur.Text.ToLower())).ToList();
        }
        if (txbSearchPatSur.Text.Count() == 0) LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.ToList();
    }

    private void txbSearchPatName_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (LTVP.ItemsSource != null)
        {
            LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.Where(x => x.NameP.ToLower().Contains(txbSearchPatName.Text.ToLower())).ToList();
        }
        if (txbSearchPatName.Text.Count() == 0) LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.ToList();
    }

    private void MenuSortSurnameP1_Click(object sender, RoutedEventArgs e)
    {
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.OrderBy(x => x.SurnameP).ToList();
    }

    private void MenuSortSurnameP2_Click(object sender, RoutedEventArgs e)
    {
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.OrderByDescending(x => x.SurnameP).ToList();
    }

    private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
    {
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.ToList();
    }

    private void MenuFilterDBP1_Click(object sender, RoutedEventArgs e)
    {
        DateTime date1 = new DateTime(2000, 1, 1);
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.Where(x => x.DateOfBirthP < date1).ToList();
    }

    private void MenuFilterDBP2_Click(object sender, RoutedEventArgs e)
    {
        DateTime date2 = new DateTime(2000, 1, 1);
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.Where(x => x.DateOfBirthP > date2).ToList();
    }

    private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
    {
        LTVP.ItemsSource = PolyclinicEntities2.GetContext().Patients.ToList();
    }

        private void MenuExportToExcelPatients_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Фамилия";
            worksheet.Cells[3][IndexRows] = "Имя";
            worksheet.Cells[4][IndexRows] = "Отчетство";
            worksheet.Cells[5][IndexRows] = "Дата рождения";
            worksheet.Cells[6][IndexRows] = "Номер телефона";
            Excel.Range headerRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[6][1]];
            headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            headerRange.Font.Bold = true;
            headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            headerRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<Patients> printItems = new List<Patients>();
            for (int i = 0; i < LTVP.Items.Count; i++) printItems.Add((Patients)LTVP.Items[i]);
            //var printItems = MiningFossilsEntities.GetContext().FossilsBD.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.SurnameP;
                worksheet.Cells[3][IndexRows + 1] = item.NameP;
                worksheet.Cells[4][IndexRows + 1] = item.PatronymicP;
                worksheet.Cells[5][IndexRows + 1] = item.DateOfBirthP;
                worksheet.Cells[6][IndexRows + 1] = item.PhoneP;
                IndexRows++;

                Excel.Range bodyRange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[6][IndexRows]];
                bodyRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[IndexRows, 1]];
                numbersRange.Font.Italic = true;
            }
            worksheet.Name = "Список пациентов";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }
    }
}
