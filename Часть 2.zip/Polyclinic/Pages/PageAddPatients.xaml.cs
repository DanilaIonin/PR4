﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddPatients.xaml
    /// </summary>
    public partial class PageAddPatients : Page
    {
        private Patients _currentPatient = new Patients();
        public PageAddPatients(Patients selectedPatient)
        {
            InitializeComponent();
            if (selectedPatient != null)
            {
                _currentPatient = selectedPatient;
                TitletxtPatient.Text = "Изменение пациента";
                BtnAddPatient.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentPatient;
        }

        private void BtnAddPatient_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentPatient.SurnameP)) error.AppendLine("Укажите фамилию пациента");
            if (string.IsNullOrWhiteSpace(_currentPatient.NameP)) error.AppendLine("Укажите имя пациента");
            if (string.IsNullOrWhiteSpace(_currentPatient.PatronymicP)) error.AppendLine("Укажите отчество пациента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentPatient.DateOfBirthP))) error.AppendLine("Укажите специализацию пациента");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentPatient.IDPatient == 0)
            {
                PolyclinicEntities2.GetContext().Patients.Add(_currentPatient);
                try
                {
                    PolyclinicEntities2.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PagePatientsListView());
                    MessageBox.Show("Новый пациент успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    PolyclinicEntities2.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PagePatientsListView());
                    MessageBox.Show("Пациент успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePatientsListView());
        }
    }
}
