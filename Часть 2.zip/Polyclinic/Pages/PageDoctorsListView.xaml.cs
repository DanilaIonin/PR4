﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDoctorsListView.xaml
    /// </summary>
    public partial class PageDoctorsListView : Page
    {
        public PageDoctorsListView()
        {
            InitializeComponent();
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
        }

        private void MenuAddDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddDoctors(null));
        }

        private void MenuEditDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddDoctors((Doctors)LTVD.SelectedItem));
        }

        private void MenuDelDoctor_Click(object sender, RoutedEventArgs e)
        {
            var doctorsForRemoving = LTVD.SelectedItems.Cast<Doctors>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {doctorsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities2.GetContext().Doctors.RemoveRange(doctorsForRemoving);
                    PolyclinicEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionVisits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVisits());
        }

        private void BtnTransitionPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePatientsListView());
        }

        private void txbSearchDocSur_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVD.ItemsSource != null)
            {
                LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.Where(x => x.SurnameD.ToLower().Contains(txbSearchDocSur.Text.ToLower())).ToList();
            }
            if (txbSearchDocSur.Text.Count() == 0) LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
        }

        private void txbSearchDocSpec_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVD.ItemsSource != null)
            {
                LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.Where(x => x.SpecializationD.ToLower().Contains(txbSearchDocSpec.Text.ToLower())).ToList();
            }
            if (txbSearchDocSpec.Text.Count() == 0) LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
        }

        private void MenuSortSurnameD1_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.OrderBy(x => x.SurnameD).ToList();
        }

        private void MenuSortSurnameD2_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.OrderByDescending(x => x.SurnameD).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
        }

        private void MenuFilterCab1_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.Where(x => x.CabinetNumber >= 10 && x.CabinetNumber <= 15).ToList();
        }

        private void MenuFilterCab2_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.Where(x => x.CabinetNumber >= 16 && x.CabinetNumber < 20).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            LTVD.ItemsSource = PolyclinicEntities2.GetContext().Doctors.ToList();
        }

        private void MenuExportToExcelDoctors_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Фамилия";
            worksheet.Cells[3][IndexRows] = "Имя";
            worksheet.Cells[4][IndexRows] = "Отчетство";
            worksheet.Cells[5][IndexRows] = "Специализация";
            worksheet.Cells[6][IndexRows] = "Номер кабинета";
            Excel.Range headerRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[6][1]];
            headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            headerRange.Font.Bold = true;
            headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            headerRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<Doctors> printItems = new List<Doctors>();
            for (int i = 0; i < LTVD.Items.Count; i++) printItems.Add((Doctors)LTVD.Items[i]);
            //var printItems = MiningFossilsEntities.GetContext().FossilsBD.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.SurnameD;
                worksheet.Cells[3][IndexRows + 1] = item.NameD;
                worksheet.Cells[4][IndexRows + 1] = item.PatronymicD;
                worksheet.Cells[5][IndexRows + 1] = item.SpecializationD;
                worksheet.Cells[6][IndexRows + 1] = item.CabinetNumber;
                IndexRows++;

                Excel.Range bodyRange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[6][IndexRows]];
                bodyRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[IndexRows, 1]];
                numbersRange.Font.Italic = true;
            }
            worksheet.Name = "Список врачей";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }
    }
}
