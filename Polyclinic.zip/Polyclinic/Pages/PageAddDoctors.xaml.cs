﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddDoctors.xaml
    /// </summary>
    public partial class PageAddDoctors : Page
    {
        private Doctors _currentDoctors = new Doctors();
        public PageAddDoctors(Doctors selectedDoctor)
        {
            InitializeComponent();
            if (selectedDoctor != null)
            {
                _currentDoctors = selectedDoctor;
                TitletxtDoctor.Text = "Изменение врача";
                BtnAddDoctor.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentDoctors;
        }

        private void BtnAddDoctor_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDoctors.SurnameD)) error.AppendLine("Укажите фамилию врача");
            if (string.IsNullOrWhiteSpace(_currentDoctors.NameD)) error.AppendLine("Укажите имя врача");
            if (string.IsNullOrWhiteSpace(_currentDoctors.PatronymicD)) error.AppendLine("Укажите отчество врача");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentDoctors.SpecializationD))) error.AppendLine("Укажите специализацию врача");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentDoctors.IDDoctor == 0)
            {
                PolyclinicEntities1.GetContext().Doctors.Add(_currentDoctors);
                try
                {
                    PolyclinicEntities1.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDoctorsListView());
                    MessageBox.Show("Новый врач успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    PolyclinicEntities1.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDoctorsListView());
                    MessageBox.Show("Врач успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDoctorsListView());
        }
    }
}
