﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddVisits.xaml
    /// </summary>
    public partial class PageAddVisits : Page
    {
        private Visits _currentVisits = new Visits();
        public PageAddVisits(Visits selectedVisit)
        {
            InitializeComponent();
            if (selectedVisit != null)
            {
                _currentVisits = selectedVisit;
                TitletxtVisit.Text = "Изменение визита";
                BtnAddVisit.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentVisits;
        }

        private void BtnAddVisit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVisits.IDPatient))) error.AppendLine("Укажите ID пациента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVisits.DateOfVisit))) error.AppendLine("Укажите дату визита");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVisits.TimeOfVisit))) error.AppendLine("Укажите время визита");
            if (string.IsNullOrWhiteSpace(_currentVisits.CurrentStatusP)) error.AppendLine("Укажите текущее состояние пациента");
            if (string.IsNullOrWhiteSpace(_currentVisits.CurrentStatusP)) error.AppendLine("Укажите текущее состояние пациента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVisits.IDDoctor))) error.AppendLine("Укажите ID врача");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVisits.StartDateOfTreatnent))) error.AppendLine("Укажите дату начала лечения");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentVisits.IDVisit == 0)
            {
                PolyclinicEntities1.GetContext().Visits.Add(_currentVisits);
                try
                {
                    PolyclinicEntities1.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVisits());
                    MessageBox.Show("Новый визит успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    PolyclinicEntities1.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVisits());
                    MessageBox.Show("Визит успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVisits());
        }
    }
}
