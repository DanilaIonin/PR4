﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePatientsListView.xaml
    /// </summary>
    public partial class PagePatientsListView : Page
    {
        public PagePatientsListView()
        {
            InitializeComponent();
            var currentPatients = PolyclinicEntities1.GetContext().Patients.ToList();
            LTVP.ItemsSource = currentPatients;
        }



        private void MenuAddPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddPatients(null));
        }

        private void MenuEditPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddPatients((Patients)LTVP.SelectedItem));
        }

        private void MenuDelPatient_Click(object sender, RoutedEventArgs e)
        {
            var patientsForRemoving = LTVP.SelectedItems.Cast<Patients>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {patientsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities1.GetContext().Patients.RemoveRange(patientsForRemoving);
                    PolyclinicEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void txbSearchPatSur_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVP.ItemsSource != null)
            {
                LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.SurnameP.ToLower().Contains(txbSearchPatSur.Text.ToLower())).ToList();
            }
            if (txbSearchPatSur.Text.Count() == 0) LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void txbSearchPatName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVP.ItemsSource != null)
            {
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.NameP.ToLower().Contains(txbSearchPatName.Text.ToLower())).ToList();
            }
            if (txbSearchPatName.Text.Count() == 0) LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void MenuSortSurnameP1_Click(object sender, RoutedEventArgs e)
        {
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.OrderBy(x => x.SurnameP).ToList();
        }

        private void MenuSortSurnameP2_Click(object sender, RoutedEventArgs e)
        {
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.OrderByDescending(x => x.SurnameP).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void MenuFilterDBP1_Click(object sender, RoutedEventArgs e)
        {
            DateTime date1 = new DateTime(2000, 1, 1);
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.DateOfBirthP < date1).ToList();
        }

        private void MenuFilterDBP2_Click(object sender, RoutedEventArgs e)
        {
            DateTime date2 = new DateTime(2000, 1, 1);
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.DateOfBirthP > date2).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            LTVP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }



    private void MenuPrintPatientExcel_Click(object sender, RoutedEventArgs e)
        { 
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "Номер";
            worksheet.Cells[2][IndexRows] = "Фамилия";
            worksheet.Cells[3][IndexRows] = "Имя";
            worksheet.Cells[4][IndexRows] = "Отчество";
            worksheet.Cells[5][IndexRows] = "Дата рождения";
            worksheet.Cells[6][IndexRows] = "Телефон";
            List<Patients> printItems = new List<Patients>();
            for (int i = 0; i < LTVP.Items.Count; i++)
            {
                printItems.Add((Patients)LTVP.Items[i]);
            }
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.SurnameP;
                worksheet.Cells[3][IndexRows + 1] = item.NameP;
                worksheet.Cells[4][IndexRows + 1] = item.PatronymicP;
                worksheet.Cells[5][IndexRows + 1] = item.DateOfBirthP;
                worksheet.Cells[6][IndexRows + 1] = item.PhoneP;
                IndexRows++;
            }
            app.Visible = true;
        }

        private void MenuPrintPatientWord_Click(object sender, RoutedEventArgs e)
        {
            var app = new Word.Application();
            Word.Document document = app.Documents.Add();
            List<Patients> printItems = new List<Patients>();
            for (int i = 0; i < LTVP.Items.Count; i++) printItems.Add((Patients)LTVP.Items[i]);

            int j = 0;

            Word.Paragraph tableParagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableParagraph.Range;
            Word.Table table = document.Tables.Add(tableRange, printItems.Count() + 1, 5);
            table.Borders.InsideLineStyle = table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
            table.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            foreach (var item in printItems)
            {
                Word.Range cellRange;

                cellRange = table.Cell(1, 1).Range;
                cellRange.Text = "Фамилия";
                cellRange = table.Cell(1, 2).Range;
                cellRange.Text = "Имя";
                cellRange = table.Cell(1, 3).Range;
                cellRange.Text = "Отчество";
                cellRange = table.Cell(1, 4).Range;
                cellRange.Text = "Дата рождения";
                cellRange = table.Cell(1, 5).Range;
                cellRange.Text = "Номер телефона";

                table.Rows[1].Range.Bold = 1;
                table.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                table.Range.Columns[1].Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalBottom;

                cellRange = table.Cell(j + 2, 1).Range;
                cellRange.Text = item.SurnameP;
                //Word.InlineShape imageShare = cellRange.InlineShapes.AddPicture(AppDomain.CurrentDomain.BaseDirectory + "..\\..\\" + item.PhotoVendor);
                //imageShare.Width = imageShare.Height = 80;
                cellRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                cellRange = table.Cell(j + 2, 2).Range;
                cellRange.Text = item.NameP;

                cellRange = table.Cell(j + 2, 3).Range;
                cellRange.Text = item.PatronymicP;

                cellRange = table.Cell(j + 2, 4).Range;
                cellRange.Text = item.DateOfBirthP.ToString();

                cellRange = table.Cell(j + 2, 5).Range;
                cellRange.Text = item.PhoneP;
                j++;
            }
            app.Visible = true;
        }
    }
}
