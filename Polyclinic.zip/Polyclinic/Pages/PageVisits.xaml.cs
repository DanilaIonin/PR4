﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVisits.xaml
    /// </summary>
    public partial class PageVisits : Page
    {
        public PageVisits()
        {
            InitializeComponent();
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void MenuAddVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits(null));
        }

        private void MenuEditVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits((Visits)DtgSQLV.SelectedItem));
        }

        private void MenuDelVisit_Click(object sender, RoutedEventArgs e)
        {
            var visitsForRemoving = DtgSQLV.SelectedItems.Cast<Visits>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {visitsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities1.GetContext().Visits.RemoveRange(visitsForRemoving);
                    PolyclinicEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSortDiagnosis1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.OrderBy(x => x.DiagnosisP).ToList();
        }

        private void MenuSortDiagnosis2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.OrderByDescending(x => x.DiagnosisP).ToList();
        }
        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void MenuFilterVisit1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.CurrentStatusP == "Больной").ToList();
        }

        private void MenuFilterVisit2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.CurrentStatusP == "Здоров").ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void txbSearchP_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.Patients.SurnameP.ToLower().Contains(txbSearchP.Text.ToLower())).ToList();
            }
            if (txbSearchP.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void txbSearchD_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.Doctors.SurnameD.ToLower().Contains(txbSearchD.Text.ToLower())).ToList();
            }
            if (txbSearchD.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void MenuPrintVisitExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "Номер";
            worksheet.Cells[2][IndexRows] = "Фамилия пациента";
            worksheet.Cells[3][IndexRows] = "Дата визита";
            worksheet.Cells[4][IndexRows] = "Время визита";
            worksheet.Cells[5][IndexRows] = "Статус пациента";
            worksheet.Cells[6][IndexRows] = "Диагноз";
            worksheet.Cells[7][IndexRows] = "Фамилия врача";
            worksheet.Cells[8][IndexRows] = "Дата начала лечения";
            List<Visits> printItems = new List<Visits>();
            for (int i = 0; i < DtgSQLV.Items.Count; i++)
            {
                printItems.Add((Visits)DtgSQLV.Items[i]);
            }
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.Patients.SurnameP;
                worksheet.Cells[3][IndexRows + 1] = item.DateOfVisit;
                worksheet.Cells[4][IndexRows + 1] = item.TimeOfVisit;
                worksheet.Cells[5][IndexRows + 1] = item.CurrentStatusP;
                worksheet.Cells[6][IndexRows + 1] = item.DiagnosisP;
                worksheet.Cells[7][IndexRows + 1] = item.Doctors.SurnameD;
                worksheet.Cells[8][IndexRows + 1] = item.StartDateOfTreatnent;
                IndexRows++;
            }
            app.Visible = true;
        }

        private void MenuPrintVisitWord_Click(object sender, RoutedEventArgs e)
        {
            var app = new Word.Application();
            Word.Document document = app.Documents.Add();
            List<Visits> printItems = new List<Visits>();
            for (int i = 0; i < DtgSQLV.Items.Count; i++) printItems.Add((Visits)DtgSQLV.Items[i]);

            int j = 0;

            Word.Paragraph tableParagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableParagraph.Range;
            Word.Table table = document.Tables.Add(tableRange, printItems.Count() + 1, 7);
            table.Borders.InsideLineStyle = table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
            table.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            foreach (var item in printItems)
            {
                Word.Range cellRange;

                cellRange = table.Cell(1, 1).Range;
                cellRange.Text = "Пациент";
                cellRange = table.Cell(1, 2).Range;
                cellRange.Text = "Дата визита";
                cellRange = table.Cell(1, 3).Range;
                cellRange.Text = "Время визита";
                cellRange = table.Cell(1, 4).Range;
                cellRange.Text = "Статус";
                cellRange = table.Cell(1, 5).Range;
                cellRange.Text = "Диагноз";
                cellRange = table.Cell(1, 6).Range;
                cellRange.Text = "Врач";
                cellRange = table.Cell(1, 7).Range;
                cellRange.Text = "Дата начала лечения";

                table.Rows[1].Range.Bold = 1;
                table.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                table.Range.Columns[1].Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalBottom;

                cellRange = table.Cell(j + 2, 1).Range;
                cellRange.Text = item.Patients.SurnameP;
                //Word.InlineShape imageShare = cellRange.InlineShapes.AddPicture(AppDomain.CurrentDomain.BaseDirectory + "..\\..\\" + item.PhotoVendor);
                //imageShare.Width = imageShare.Height = 80;
                cellRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                cellRange = table.Cell(j + 2, 2).Range;
                cellRange.Text = item.DateOfVisit.ToString();

                cellRange = table.Cell(j + 2, 3).Range;
                cellRange.Text = item.TimeOfVisit.ToString();

                cellRange = table.Cell(j + 2, 4).Range;
                cellRange.Text = item.CurrentStatusP;

                cellRange = table.Cell(j + 2, 5).Range;
                cellRange.Text = item.DiagnosisP;

                cellRange = table.Cell(j + 2, 6).Range;
                cellRange.Text = item.Doctors.SurnameD;

                cellRange = table.Cell(j + 2, 7).Range;
                cellRange.Text = item.StartDateOfTreatnent.ToString();
                j++;
            }
            app.Visible = true;
        }
    }
}
